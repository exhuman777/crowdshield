# CrowdShield - Game Theory Deep Dive

## Actors

| Actor | Inputs | Incentive | Reward |
|-------|--------|-----------|--------|
| **Fan** | Ticket price + cover premium | Protect against event failure collateral damage | Payout on event failure (100-1000 USDC, fan chooses), profit on cover resale |
| **Organizer** | Optional bond stake + event listing | Sell more tickets, earn cover revenue share, get demand intelligence | Bond return + yield, cover spread share, analytics |
| **LP** | USDC capital (platform bootstraps initial pool) | Earn yield from premiums | Premium share + DeFi yield on idle capital |
| **Sentinel** | Reputation stake | Earn resolution fees, status | Fee share + reputation growth |

## 1. Cover Pricing Engine (Bonding Curve AMM)

Each event has a Cover Pool. Cover price is dynamic:

```
CoverPrice = BasePremium * ControversyMultiplier * DemandCurve * TimeDecay

BasePremium:
  cancellation:      3.0% of payout
  delay:             1.5% of payout
  headliner_changed: 2.0% of payout
  weather_rain:      1.8% of payout
  venue_changed:     2.0% of payout

ControversyMultiplier = 1 + (controversy_score / 100)^2
  score 0:   mult = 1.00
  score 30:  mult = 1.09
  score 50:  mult = 1.25
  score 70:  mult = 1.49
  score 92:  mult = 1.85

DemandCurve = 1 + (covers_sold / max_tickets)^3
  0% covered:  1.00
  20% covered: 1.008
  50% covered: 1.125
  80% covered: 1.512

TimeDecay = 1 + 1/sqrt(days_to_event)
  90 days: 1.105
  30 days: 1.183
  7 days:  1.378
  1 day:   2.000
```

### Price Evolution Example (Wireless, Cancellation Cover, 300 USDC payout)

| Day | Controversy | Covers/Tickets | Days Out | Premium | % of Payout |
|-----|-------------|---------------|----------|---------|-------------|
| D-90 | 35 | 5% | 90 | 10.38 USDC | 3.5% |
| D-80 | 55 | 15% | 80 | 16.92 USDC | 5.6% |
| D-75 | 75 | 30% | 75 | 27.36 USDC | 9.1% |
| D-70 | 85 | 42% | 70 | 37.20 USDC | 12.4% |
| D-60 | 92 | 55% | 60 | 59.04 USDC | 19.7% |
| D-30 | 92 | 65% | 30 | 74.40 USDC | 24.8% |
| D-7 | 95 | 78% | 7 | 132.96 USDC | 44.3% |
| D-1 | 95 | 85% | 1 | 233.40 USDC | 77.8% |

Early buyers are rewarded. Late buyers pay for certainty.

**Fan-configurable payout tiers**: 100 / 300 / 500 / 1000 USDC. Premiums scale linearly with payout. A fan choosing 100 USDC payout at D-90 pays ~3.46 USDC. Same moment, 1000 USDC payout costs ~34.60 USDC.

## 2. Organizer Bond Mechanism

Organizer bond is **optional**. Platform can list events without organizer participation. When organizers do bond, tiered trust system applies:

```
Bond Size ──→ Trust Score ──→ Cover Price Impact ──→ Ticket Sales

Bond is OPTIONAL. Organizers can list without bonding.

Trust Tiers (opt-in):
  No bond           → "Listed"       → no badge, default pricing
  0.5% bond ratio   → "Starter"     → basic badge
  2-5%  bond ratio  → "Standard"    → neutral pricing, trust badge
  5-10% bond ratio  → "Trusted"     → controversy base -15%
  > 10% bond ratio  → "Guaranteed"  → controversy base -30%, featured placement
```

### Slash Rules (Binary)

| Scenario | Bond Outcome |
|----------|-------------|
| Event happens normally | Full bond returned + yield earned while staked |
| Event cancelled, force majeure (govt ban, weather) | 80% bond returned, 20% to cover pool |
| Event cancelled, organizer fault | 100% bond slashed into cover pool |
| Headliner changed | 30% bond slashed |

### Why Organizers Stake

1. Higher bond = lower cover prices = fans feel safer = more tickets sold
2. "Guaranteed" badge = premium marketing placement on platform
3. Bond earns DeFi yield while staked (Kamino/MarginFi, ~4-6% APY)
4. Successful event = bond + yield returned = net positive
5. Cover revenue share (organizer gets 2% of premiums from their event)

**No bond required to start**: platform can onboard events unilaterally using public event data. Organizer participation improves pricing but isn't a dependency.

## 3. LP Economics

```
LP deposits USDC → Pool Vault → Earns premiums + idle yield

Pool Bootstrap:
  Platform seeds initial LP pool from treasury
  No dependency on external LPs day 1
  External LPs join as pool grows and yields prove out

Pool Types:
  Single Event Pool: high risk, high return (8-25% annualized)
  Category Pool:     medium risk (5-12% annualized)  
  Global Pool:       low risk, diversified (3-8% annualized)
```

### LP Yield at Different Cancellation Rates

Assuming diversified Global Pool, 100k USDC deposited, 50 events/month:

| Cancellation Rate | Net APY | LP Outcome |
|-------------------|---------|------------|
| 1% (rare cancellations) | ~72% | Strong profit |
| 3% (normal market) | ~48% | Healthy profit |
| 5% (high-risk year) | ~12% | Break-even |
| 7% (crisis year) | -15% | LP loses money |
| 10%+ (black swan) | -40%+ | Significant loss |

**Honest risk disclosure**: LP can lose money if cancellation rate exceeds ~5%. The bonding curve and pool cap (80% max exposure) limit downside but don't eliminate it.

### LP Profit/Loss Scenarios

**Scenario A: Event happens normally (most common)**
- LP deposited: 10,000 USDC
- Pool share: 10%
- Total premiums collected: 20,000 USDC (2,000 covers, avg 10 USDC premium)
- LP's premium share: 2,000 USDC
- Idle yield (60 days): ~100 USDC
- LP profit: **2,100 USDC (~21% for the event period)**

**Scenario B: Event cancelled, 40% of tickets covered (300 USDC avg payout)**
- LP deposited: 10,000 USDC
- Pool share: 10%
- Premiums collected: 20,000 USDC
- Total payouts: 240,000 USDC (800 covers x 300 USDC avg)
- Pool must cover payouts from: LP deposits + premiums + organizer bond slash
- LP loss depends on pool size vs total payouts. With sufficient pooling across events, losses spread.

**Key protections:**
- Pool capacity cap at 80%: total exposure never exceeds 80% of pool liquidity
- Remaining 20% = reserve
- Bonding curve spikes prices as exposure approaches capacity
- Diversified pools spread risk across many events

### Idle Capital Yield

USDC sitting in pool waiting for resolution flows to:
- Kamino USDC vaults (~4-6% APY)
- MarginFi lending (~3-5% APY)
- Auto-withdrawn on resolution for payouts

LP earns premiums + DeFi yield. Double income.

## 4. Controversy Oracle (Multi-Source)

```
Score = 0.4 * Algorithmic + 0.3 * MarketSignal + 0.3 * ParticipantSignal

Algorithmic (40%):
  - News sentiment API (GDELT, NewsAPI): volume + sentiment score
  - Social media mentions: X/Twitter volume + sentiment
  - Corporate signals: sponsor withdrawals, partnership changes
  - Political signals: government statements, regulatory actions

Market Signal (30%):
  - Cover purchase rate (acceleration of demand)
  - Cover price trajectory (rising = more risk perceived)
  - Secondary ticket price (dropping = less confidence)

Participant Signal (30%):
  - Fan polls (ticket-holder weighted votes)
  - Sentinel validations (high-rep users confirming/denying signals)
  - Organizer actions (updates, statements)
```

### Update Frequency

- Algorithmic: every 15 minutes (batch API calls)
- Market signal: real-time (on every cover purchase)
- Participant signal: on every vote/validation
- Published score: updated every block (~400ms)

## 5. Cover NFT Secondary Market

Cover = SPL Token (NFT) with metadata:
- Cover type
- Event reference
- Payout amount (fan-selected tier: 100/300/500/1000 USDC)
- Premium paid
- Purchase timestamp

**Tradeable on any Solana NFT marketplace** (Tensor, Magic Eden).

### Secondary Market Dynamics

| Condition | Cover Floor Price |
|-----------|------------------|
| Controversy drops | Below premium paid (loss) |
| Controversy stable | Near current premium price |
| Controversy rises | Above premium paid (profit) |
| Near resolution (high controversy) | Approaches payout value |

### Who Trades

- **Fan who wants out**: bought cover, controversy dropped, wants to cut losses
- **Fan who wants in late**: new covers too expensive (bonding curve), secondary may be cheaper
- **Speculators (open tier)**: can buy Cover NFTs on secondary (can't mint new ones without ticket)
- **Arbitrageurs**: if secondary price < primary minting price, arb opportunity

### Platform Revenue from Secondary

5% royalty on every Cover NFT resale. Enforced on-chain via Metaplex royalty standard.

## 6. Tiered Access

| Tier | Requirement | Capabilities |
|------|------------|-------------|
| 0: Spectator | None (email login) | View events, scores, public polls, social feed, buy Cover NFTs on secondary |
| 1: Fan | Holds Ticket NFT | Mint covers (choose payout tier), vote in polls (1x weight), post in community, earn reputation |
| 2: SuperFan | Ticket + stake or Platform NFT | 2x poll weight, 10% cover discount, group cover creation, referral revenue |
| 3: Sentinel | Tier 2 + reputation threshold | Dispute resolution, oracle validation, earns resolution fees |

**Key design: Tier 0 CAN buy covers on secondary market, but CANNOT mint new covers.**
This preserves insurable interest for minting while providing liquidity for secondary trading.

## 7. Resolution (3-Layer, Binary Only)

```
Layer 1: Automatic Oracle (90% of cases)
  - Switchboard custom feed: venue API, news aggregator, weather API
  - Binary: event_cancelled = true/false
  - Triggers auto-payout within same transaction
  - No human involvement

Layer 2: Authority Override (9% of cases)
  - Platform multisig (3/5 signatures)
  - Used when oracle data ambiguous or delayed
  - Transparent: resolution TX logged on-chain with reason

Layer 3: Sentinel Committee (1% of cases, future)
  - 7/11 randomly selected Sentinels vote
  - Each stakes reputation
  - Majority wins
  - Used for edge cases only
```

### Resolution Timeline

- Event date passes → 24h oracle observation window
- If clear outcome: auto-resolve at hour 0
- If ambiguous: authority review within 24h
- All covers for an event resolved within 48h max
- Payouts: instant upon resolution (same transaction)

## 8. Anti-Manipulation Matrix

| Attack Vector | Mitigation |
|---------------|-----------|
| Fan sabotages event to trigger cover | Cover payout (100-1000 USDC) << cost of sabotage. No economic incentive. |
| Organizer cancels to drain pool | Bond slashed 100%. Always net negative for organizer. |
| Fake event + drain LP | Organizer bond (when posted) + Sentinel pre-listing review (Phase 3). Platform-listed events use verified public data. |
| Whale drains pool via mass cover purchase | Bonding curve: exponential price increase. Pool cap at 80%. |
| Sybil attack on polls | Ticket-gated voting (1 ticket = 1 vote). No way to multiply cheaply. |
| Controversy score manipulation | 40% algorithmic (hard to manipulate), multi-source verification. |
| Insider trading (organizer buys covers then cancels) | On-chain transparency. Organizer address excluded from cover minting on own events. |
| Oracle manipulation | Multi-source oracle. Authority override as backstop. Future: Sentinel committee. |

## 9. Flywheel

```
More fans buy tickets
       │
       ▼
More cover purchases ──→ Better controversy score accuracy
       │                            │
       ▼                            ▼
Higher LP yields ◄──── More LP capital ──→ Cheaper covers
       │                                        │
       ▼                                        ▼
More LP deposits              More fans attracted
       │                            │
       ▼                            ▼
Bigger pools ──→ More events viable ──→ More organizers join
                                              │
                                              ▼
                                    More events ──→ REPEAT
```

Each actor optimizing for self-interest strengthens the system for everyone.

## 10. Why This Game Theory Works

1. **No zero-sum**: Fan protection AND LP yield AND organizer sales. Everyone can win.
2. **Honest signals**: Cover price = real risk signal. Can't be faked cheaply (bonding curve + oracle).
3. **Skin in the game**: Organizer bond (optional but incentivized), LP capital, fan premium, Sentinel reputation. Everyone has something to lose.
4. **Self-regulating**: Bonding curve prevents pool drain. Bond slash prevents organizer abuse. Ticket-gating prevents sybils.
5. **Binary = no disputes**: YES or NO. Oracle says, system pays. No committees, no arguments, no delays.
6. **Honest risk**: LPs can lose money at >5% cancellation rate. No hidden risk, no false promises.

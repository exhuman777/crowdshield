# CrowdShield - Pitch Deck

## Slide 1: Hook

**Yesterday, Wireless Festival was cancelled. 50,000 fans lost their flights and hotels.**

Ye banned from the UK by the Home Office. Pepsi, Diageo, Rockstar, PayPal pulled sponsorship. UK PM Starmer condemned the booking.

> April 7, 2026: Wireless Festival officially cancelled. 50,000 ticket holders stranded with non-refundable travel.

---

## Slide 2: The Problem

You buy a concert ticket. You book a flight. You take time off work.

**Event gets cancelled.**

You get your ticket refund. You DON'T get back:
- $400 flight
- $200 hotel
- 3 vacation days
- The experience you planned around

**40+ festivals cancelled in 2025 alone** (source: musicfestivalwizard.com). And 2026 keeps the trend:
- **Wireless Festival 2026**: Cancelled April 7. Ye banned by UK Home Office.
- **Rock the Country 2026**: Kid Rock festival cancelled after artists (Shinedown etc.) withdrew over political concerns.
- **Midwest Dreams (St. Louis)**: Cancelled 1 week before, fans given 24h refund window.
- **Pitchfork Music Festival**: 20-year Chicago institution, shut down after 2024.
- **2026 FIFA World Cup**: Weather delay fears, Iran war postponement rumors (FIFA confirmed proceeding).

**$6.5 BILLION** ticket refund insurance market (2025), projected $23.3B by 2035, CAGR 13.6% (source: market.us).

Every player in this market (Allianz, AXA, Cover Genius) operates in TradFi:
- Slow claims (7-30 days)
- No transparency
- Static pricing
- Zero social layer
- No dynamic risk assessment

---

## Slide 3: The Solution

**CrowdShield**: Event protection for fans. On-chain. Instant. Social.

1. **Browse events** with live Controversy Score (0-100)
2. **Buy ticket** (Apple Pay, card, or USDC)
3. **Choose your Cover**: 100 / 300 / 500 / 1000 USDC payout. One tap.
4. Event cancelled? **Auto-payout in 3 seconds.** No claims. No forms.

Example: Protect against cancellation for ~11 USDC premium, 300 USDC payout.

Cover = NFT. Tradeable on secondary market.
Controversy rises = your cover becomes more valuable.

**Fan sees a consumer app. Under the hood: Solana DeFi.**

---

## Slide 4: Live Demo

### Demo Script (2.5 min)

1. Open app. Browse events. See Wireless Festival with Controversy Score: CANCELLED (red, confirmed)
2. Open event page. See timeline: sponsors left, PM condemned, Home Office banned Ye, CANCELLED
3. Buy ticket for another at-risk event (one tap, Apple Pay UX)
4. See cover options: "Event Cancelled", "Delayed 2+ Hours", "Headliner Replaced"
5. Choose payout tier: 300 USDC. Premium: ~11 USDC
6. Cover NFT appears in "My Covers". Current market value: ~21 USDC (already +91% since controversy rose)
7. See live polls: "Will the headliner show? YES 35% / NO 48% / Replaced 17%"
8. See social feed: real-time activity from other fans
9. **SIMULATE: Event Cancelled** (press button)
10. Oracle confirms. 3 seconds. **300.00 USDC hits wallet.** Done.

---

## Slide 5: How It Works

```
Fan pays premium ───→ COVER POOL ←─── LP provides capital (bootstrapped by platform treasury)
                          │
Oracle triggers ──→ Binary Resolution (YES/NO)
                          │
                    Auto-payout to fan
```

- **Cover = NFT**: tradeable on secondary market
- **Configurable payout**: fan chooses 100 / 300 / 500 / 1000 USDC
- **Bonding curve pricing**: more covers sold = price rises = self-regulating
- **Controversy Oracle**: news API (40%) + market signal (30%) + fan polls (30%)
- **Binary resolution**: cancelled YES/NO. Delayed YES/NO. No gray areas.

---

## Slide 6: Market Opportunity

| Segment | Size | Growth | Source |
|---------|------|--------|--------|
| Ticket Refund Insurance | $6.5B (2025) | → $23.3B (2035), 13.6% CAGR | market.us |
| Event Cancellation Insurance | $3.2B (2024) | Growing | growthmarketreports.com |
| Sports & Event Cancellation | $286M (2024) | → $866M (2034), 11.7% CAGR | market.us |

**Recent signals**:
- Allianz launched ticket protection for Milano Cortina 2026 Olympics (source: allianz.com)
- 40+ festivals cancelled in 2025 alone (source: musicfestivalwizard.com)

**Incumbents**: Allianz, AXA XL, Cover Genius, Arch Insurance

All TradFi. All slow. None offer:
- Dynamic pricing based on real-time risk
- Tradeable cover positions
- Social layer / community
- Instant on-chain settlement
- Controversy scoring

---

## Slide 7: Business Model

| Revenue Stream | Source | Take Rate |
|----------------|--------|-----------|
| Cover spread | % of premiums | 10-15% |
| Cover NFT secondary royalty | Resale of covers | 5% |
| Yield fee | DeFi yield on idle pool capital | 10% of yield |
| Organizer SaaS | Dashboard, analytics, sentiment | Freemium / $99 mo |
| Promoted events | Featured placement | Bid-based |

**Unit economics (conservative, per-event average):**
- 2,000 covers sold, avg premium 10 USDC = 20,000 USDC premiums
- Platform spread 12% = **2,400 USDC**
- Secondary Cover NFT volume ~50k USDC, 5% royalty = **2,500 USDC**
- **~4,900 USDC from one event**

**Scaling targets (realistic):**
- 10 events/month = ~$240k USDC/year revenue
- Break-even at ~20 events/month
- Comfortable profit at 50+ events/month

---

## Slide 8: Game Theory (The Moat)

### Four actors, aligned incentives:

**Fan** buys cover early (cheaper), chooses payout tier (100-1000 USDC) based on travel exposure.

**Organizer** optionally stakes bond (tiered: 0.5% starter to 10% guaranteed) to lower cover prices and sell more tickets.

**LP** provides capital (platform bootstraps initial pool from treasury). Earns premiums + DeFi yield.

**Everyone benefits when the system is honest.**

### Key mechanisms:
- **Bonding curve**: more covers bought = higher price = pool can't be drained
- **Optional organizer bond**: staked capital, slashed if event cancelled by fault = skin in the game
- **Ticket-gated minting**: only ticket holders can mint new covers = insurable interest = regulatory edge
- **Open secondary market**: anyone can BUY existing Cover NFTs = liquidity + price discovery
- **Binary resolution**: no disputes, no subjectivity = trust the oracle

---

## Slide 9: Why Now

1. **Polymarket proved demand** for event outcome markets ($2B+ volume)
2. **But Polymarket has an ethics crisis**: war bets, pilot rescue bets, nuclear detonation bets. Congress introducing bans.
3. **CrowdShield is NOT gambling.** Fan protection. Insurable interest.
4. **Wireless cancelled April 7, 2026**: real-world proof the problem exists NOW
5. **40+ festivals cancelled in 2025**: systemic problem, not a one-off
6. **Rock the Country cancelled**: political toxicity kills events too
7. **Solana infra mature**: cNFTs ($0.0001/mint), account abstraction (Squads passkeys), Blinks (viral distribution)

---

## Slide 10: Why Solana

| Need | Solana Solution |
|------|----------------|
| Mass ticket minting (50k+) | cNFTs: ~$110 for 1M mints |
| Micro-covers ($1-3 USDC) | Sub-cent transaction fees |
| Non-crypto UX | Squads passkeys + session keys |
| Instant payout | 400ms finality |
| Real-time risk data | Switchboard custom oracle feeds |
| Viral distribution | Blinks: vote in polls from X/Twitter |
| Idle yield | Kamino, MarginFi integration |

---

## Slide 11: Competitive Landscape

|                   | On-chain | Social Layer | Dynamic Pricing | Tradeable Covers | Instant Payout |
|-------------------|----------|-------------|-----------------|-----------------|----------------|
| **Allianz/AXA**   |    -     |      -      |        -        |        -        |       -        |
| **Cover Genius**  |    -     |      -      |        -        |        -        |       -        |
| **Polymarket**    |    +     |      -      |        +        |        -        |       +        |
| **Kalshi**        |    -     |      -      |        +        |        -        |       -        |
| **CrowdShield**   |    +     |      +      |        +        |        +        |       +        |

**Key differentiator**: CrowdShield combines event ticketing, parametric insurance, social community, and tradeable risk positions in one consumer-facing product.

---

## Slide 12: Traction / Validation

- Working demo on Solana devnet
- Smart contracts: event creation, ticket minting, cover purchase, binary resolution, payout claim
- Frontend: non-crypto UX, controversy gauge, cover pricing engine, resolution simulator
- **Real-world validation**: Wireless Festival cancelled April 7, 2026, proving exact use case
- **Market validation**: 40+ festivals cancelled in 2025, Allianz launching Olympic ticket protection
- Target: first pilot with 3-5 event organizers within 3 months

---

## Slide 13: Roadmap

**Phase 0 (NOW)**: Hackathon demo. Core smart contracts + frontend.

**Phase 1 (Months 1-3)**: Testnet MVP. Platform-bootstrapped LP pool, bonding curve pricing, account abstraction, fiat on-ramp, Cover NFT secondary market, basic social feed, 2-3 pilot events.

**Phase 2 (Months 4-6)**: Mainnet launch. Yield routing, organizer dashboard, group covers, reputation system, Blinks distribution, ticketing platform integrations.

**Phase 3 (Months 7-12)**: Scale. Mobile app, white-label for organizers, multi-category (music, sport, conferences, travel), global cover pools.

---

## Slide 14: Team

[Team members and relevant experience]

---

## Slide 15: Ask

**Hackathon**: "We're building the Robinhood of event protection. Every fan deserves peace of mind."

**Seed**: Raising $X for 18 months runway. Milestones: mainnet launch, 50 events, 10k covers sold, 3 organizer partnerships.

---

## One-Liner Options

- "Event protection for fans. Prediction markets disguised as peace of mind."
- "Buy a ticket. Add a cover. Sleep well."
- "The insurance layer for live events, powered by Solana."
- "Protecting fans from the collateral damage of cancelled events."

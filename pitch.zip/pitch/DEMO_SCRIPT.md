# CrowdShield - Demo Script

## Setup Before Demo

1. Open app in browser (localhost:3000 or deployed URL)
2. Have the demo wallet pre-loaded (mock state: has USDC, has 1 ticket, has 1 cover)
3. Browser in dark mode
4. Full screen, no browser chrome visible if possible

## Script (5 minutes total)

### ACT 1: The Hook (30 sec)

> "On April 7th, Wireless Festival was cancelled. 50,000 fans had already booked flights and hotels to London. Ye was banned from the UK by the Home Office after sponsors fled and the Prime Minister condemned the booking."
>
> "Ticket refunds were issued. Flights, hotels, vacation days, none of that came back."
>
> "This is why CrowdShield exists."

### ACT 2: Browse Events (30 sec)

*Show home page*

> "Four events. Notice the Controversy Score on each card. Champions League Final: 15, calm. Solana Breakpoint: 5, nothing to worry about. Local Jazz Night: 0."
>
> "Wireless Festival: CANCELLED. Red. This one already happened, April 7th. Let's look at how CrowdShield would have protected those fans."

*Click on Wireless Festival*

### ACT 3: Event Page (1 min)

*Show the controversy gauge prominently*

> "This is what a fan sees. Controversy Score 92 out of 100. Fed by three sources: news sentiment algorithms catching sponsor withdrawals and political statements. Market signal from cover purchase rates. And fan polls from ticket holders."
>
> "Below, you see the timeline: PayPal withdraws, PM condemns, Pepsi pulls out. All feeding the score in real-time."

*Scroll to cover section*

> "Here's where CrowdShield protects you. Five cover types, all binary: Event Cancelled, Delayed 2+ Hours, Headliner Replaced, Rain at Venue, Venue Changed."
>
> "You choose how much coverage you need. 100, 300, 500, or 1000 USDC. For 300 USDC cancellation cover, the premium right now is about 21 USDC. 90 days ago, when controversy was low, same cover cost about 11 USDC. Price rises with demand, controversy, and proximity to event."
>
> "One tap. Add Cover. Apple Pay. No wallet. No gas fees. No DeFi jargon."

### ACT 4: Your Covers (30 sec)

*Show the user's existing cover*

> "I bought this 300 USDC cancellation cover a few weeks ago for about 11 USDC. The controversy was at 35 then."
>
> "Today, same cover costs ~21 USDC to mint fresh. My Cover NFT's market value: about 21 USDC. That's nearly double what I paid. I can sell it right now on secondary market to someone who wants protection but doesn't want to pay the current bonding curve price."
>
> "Or I can hold it. If the event gets cancelled, I get 300 USDC. If it doesn't, I lost 11."

### ACT 5: Social Layer (30 sec)

*Show polls and social feed*

> "Live polls from ticket holders: 'Will Ye actually perform?' 48% say no. 12,400 votes."
>
> "Social feed: Sarah just bought a cancellation cover. ConcertKing listed his cover for resale at 18 USDC. NewsBot flagged PayPal withdrawal. A fan club created a group cover for 12 members."
>
> "This isn't a prediction market. This is a fan community with built-in protection tools."

### ACT 6: The Resolution (1 min) - THE MONEY SHOT

*Navigate to Resolution Simulator*

> "Wireless was cancelled. The UK government banned Ye. Let's see what happens."

*Click "Simulate: Event Cancelled"*

> "Oracle confirms cancellation..."

*Wait for animation: resolving spinner*

> "Binary resolution: YES."

*Payout animation: 300.00 USDC counting up*

> "300 USDC. In my wallet. 3 seconds. No claims form. No waiting 30 days. No calling customer support."
>
> "I paid 11 USDC for this cover. My flight was 400 dollars. My hotel was 200. 300 USDC covers most of that. Instantly."

*Show completion state*

> "Every cover holder for this event just got paid. Automatically. Same transaction."

### ACT 7: Why This Matters (30 sec)

> "6.5 billion dollar ticket insurance market. Growing to 23 billion by 2035. Allianz, AXA, Cover Genius, all doing this with paper forms and 7-to-30-day claim processes."
>
> "CrowdShield does it in 3 seconds on Solana. Dynamic pricing that reflects real-time risk. Tradeable covers that create a secondary market. A social layer that turns protection into community."

### ACT 8: Close (30 sec)

> "Polymarket proved people want to bet on events. But they're betting on wars and pilot rescues. Congress is shutting them down."
>
> "We're not gambling. We're protecting fans. Ticket holders with insurable interest. Binary outcomes. Real events that affect real people's plans."
>
> "CrowdShield. Buy a ticket. Add a cover. Sleep well."

## Key Demo Tips

- **Speed**: Don't linger on any screen. The demo should feel fast and fluid.
- **Story**: Always come back to the Ye/Wireless story. Judges remember stories, not features.
- **Contrast**: Always contrast with TradFi ("Allianz takes 30 days, we take 3 seconds")
- **Numbers**: Use real market numbers ($6.5B, 13.6% CAGR). Judges love validated markets.
- **Don't explain the tech**: Never say "PDA", "cNFT", "bonding curve" to judges. Say "dynamic pricing", "digital ticket", "instant payout".

## Backup Talking Points (Q&A)

**"How do you resolve disputes?"**
We don't. Binary resolution only. Event cancelled: yes or no. Oracle confirms, payout triggers. No committees, no arguments.

**"What about regulatory risk?"**
Ticket-gated minting = insurable interest. We're closer to consumer protection than gambling. Polymarket's problem is letting anyone bet on anything. We require a ticket.

**"Who provides liquidity?"**
Platform bootstraps initial LP pool from treasury, no external LP dependency day 1. As yields prove out, external LPs join. They deposit USDC, earn premiums + idle DeFi yield. Event goes fine = LPs keep everything. Similar to insurance underwriting but transparent and permissionless.

**"Why Solana?"**
cNFTs ($0.0001 per ticket mint), sub-cent transaction fees (micro-covers viable), 400ms finality (instant payouts), Squads account abstraction (no wallet UX), Blinks (viral poll distribution on X).

**"What's your moat?"**
Network effects. More fans = better controversy scoring = more LP yield = more capital = cheaper covers = more fans. Plus Cover NFT secondary market creates liquidity lock-in.

**"Who is your first customer?"**
We don't need organizer buy-in to start. Platform lists events using public data. Organizers can opt in for trust badges and cover revenue share. Starting with crypto conferences and music festivals, expanding to sports.

**"What if cancellation rates spike?"**
Honest answer: LPs can lose money above ~5% cancellation rate. Bonding curve + 80% pool cap limit exposure, but risk exists. At 3% (normal market), LPs earn ~48% APY. We disclose this upfront.
